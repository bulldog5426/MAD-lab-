package com.example.everythingapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class BookingAdapter extends CursorAdapter {
    public BookingAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.booking_item, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvDetails = view.findViewById(R.id.tvBookingDetails);

        String details = "Name: " + cursor.getString(cursor.getColumnIndex("name")) + "\n" +
                "Age: " + cursor.getInt(cursor.getColumnIndex("age")) + "\n" +
                "Date: " + cursor.getString(cursor.getColumnIndex("date")) + "\n" +
                "Time: " + cursor.getString(cursor.getColumnIndex("time")) + "\n" +
                "Seat: " + cursor.getString(cursor.getColumnIndex("seat_type"));

        tvDetails.setText(details);
    }
}
