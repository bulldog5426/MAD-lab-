package com.example.everythingapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;

public class BookTicketFragment extends Fragment {
    private EditText editTextName, editTextAge;
    private TextView textViewDate, textViewTime;
    private Spinner spinnerSeatType;
    private CheckBox checkBoxMeal;
    private RadioGroup radioGroupInsurance;
    private Button buttonBookTicket;
    private ToggleButton toggleButtonNotifications;
    private DatabaseHelper databaseHelper;
    private String selectedDate = "";
    private String selectedTime = "";
    private String username;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_book_ticket, container, false);

        if (getActivity() instanceof com.example.everythingapp.MainActivity) {
            username = ((com.example.everythingapp.MainActivity) getActivity()).getUsername();
        } else {
            username = "Guest"; // Fallback value
        }
        databaseHelper = new DatabaseHelper(getContext());

        editTextName = view.findViewById(R.id.editTextName);
        editTextAge = view.findViewById(R.id.editTextAge);
        textViewDate = view.findViewById(R.id.textViewDate);
        textViewTime = view.findViewById(R.id.textViewTime);
        spinnerSeatType = view.findViewById(R.id.spinnerSeatType);
        checkBoxMeal = view.findViewById(R.id.checkBoxMeal);
        radioGroupInsurance = view.findViewById(R.id.radioGroupInsurance);
        buttonBookTicket = view.findViewById(R.id.buttonBookTicket);
        toggleButtonNotifications = view.findViewById(R.id.toggleButtonNotifications);

        // Register for context menu
        registerForContextMenu(editTextName);

        // Setup spinner
        String[] seatTypes = {"Economy", "Business", "First Class"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, seatTypes);
        spinnerSeatType.setAdapter(adapter);

        // Date picker
        textViewDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                                textViewDate.setText("Date: " + selectedDate);
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });


        // Time picker
        textViewTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(),
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                selectedTime = hourOfDay + ":" + minute;
                                textViewTime.setText("Time: " + selectedTime);
                            }
                        }, hour, minute, true);
                timePickerDialog.show();
            }
        });
        // Toggle button for notifications
        toggleButtonNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isOn = toggleButtonNotifications.isChecked();
                Toast.makeText(getContext(), "Notifications " + (isOn ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
            }
        });

        // Popup menu for additional options
        editTextAge.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showPopupMenu(v);
                return true;
            }
        });

        // Add this in onCreateView after initializing views
        Button buttonClear = view.findViewById(R.id.buttonClear);
        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearAllFields();
            }
        });



        // Book ticket button
        buttonBookTicket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String ageStr = editTextAge.getText().toString();
                String seatType = spinnerSeatType.getSelectedItem().toString();
                boolean includeMeal = checkBoxMeal.isChecked();
                boolean includeInsurance = radioGroupInsurance.getCheckedRadioButtonId() == R.id.radioButtonInsuranceYes;

                if (name.isEmpty() || ageStr.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
                    Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int age = Integer.parseInt(ageStr);

                // Add booking to database
                boolean isSuccess = databaseHelper.addBooking(username, name, age, selectedDate, selectedTime, seatType);

                if (isSuccess) {
                    // Create booking details to pass to ticket activity
                    Intent intent = new Intent(getActivity(), com.example.everythingapp.TicketActivity.class);
                    intent.putExtra("name", name);
                    intent.putExtra("age", age);
                    intent.putExtra("date", selectedDate);
                    intent.putExtra("time", selectedTime);
                    intent.putExtra("seatType", seatType);
                    intent.putExtra("includeMeal", includeMeal);
                    intent.putExtra("includeInsurance", includeInsurance);
                    startActivity(intent);
                } else {
                    Toast.makeText(getContext(), "Failed to book ticket", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    private void clearAllFields() {
        editTextName.setText("");
        editTextAge.setText("");
        textViewDate.setText("Select Date");
        textViewTime.setText("Select Time");
        spinnerSeatType.setSelection(0);
        checkBoxMeal.setChecked(false);
        radioGroupInsurance.clearCheck();
        toggleButtonNotifications.setChecked(false);
        selectedDate = "";
        selectedTime = "";
    }

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(getContext(), view);
        popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.menu_clear) {
                    editTextAge.setText("");
                    return true;
                } else if (itemId == R.id.menu_set_adult) {
                    editTextAge.setText("30");
                    return true;
                } else if (itemId == R.id.menu_set_child) {
                    editTextAge.setText("10");
                    return true;
                } else {
                    return false;
                }
            }
        });

        popupMenu.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.menu_clear_name) {
            editTextName.setText("");
            return true;
        } else if (itemId == R.id.menu_set_default_name) {
            editTextName.setText("John Doe");
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }

}
