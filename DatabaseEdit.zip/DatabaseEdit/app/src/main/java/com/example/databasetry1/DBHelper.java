package com.example.databasetry1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "StudentDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, gender TEXT, subjects TEXT, class TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Students");
        onCreate(db);
    }

    public void insertStudent(String name, String gender, String subjects, String className) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("gender", gender);
        cv.put("subjects", subjects);
        cv.put("class", className);
        db.insert("Students", null, cv);
    }

    public void updateStudent(String id, String name, String gender, String subjects, String className) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("gender", gender);
        cv.put("subjects", subjects);
        cv.put("class", className);
        db.update("Students", cv, "id=?", new String[]{id});
    }


    public ArrayList<String> getAllStudents() {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM Students", null);
        while (c.moveToNext()) {
            String entry = c.getInt(0) + ": " + c.getString(1) + ", " + c.getString(2) + ", " + c.getString(3) + ", " + c.getString(4);
            list.add(entry);
        }
        c.close();
        return list;
    }

    public void deleteStudent(String id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("Students", "id=?", new String[]{id});
    }
}