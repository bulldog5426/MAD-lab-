package com.example.moviereviews;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText etMovieName, etMovieYear, etMovieRating;
    Button btnAddReview;
    ListView listMovies;
    TableLayout tableMovieDetails;
    TextView tvMovieName, tvMovieYear, tvMovieRating;
    ArrayList<String> movieList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        etMovieName = findViewById(R.id.et_movie_name);
        etMovieYear = findViewById(R.id.et_movie_year);
        etMovieRating = findViewById(R.id.et_movie_rating);
        btnAddReview = findViewById(R.id.btn_add_review);
        listMovies = findViewById(R.id.list_movies);
        tableMovieDetails = findViewById(R.id.table_movie_details);
        tvMovieName = findViewById(R.id.tv_movie_name);
        tvMovieYear = findViewById(R.id.tv_movie_year);
        tvMovieRating = findViewById(R.id.tv_movie_rating);

        movieList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, movieList);
        listMovies.setAdapter(adapter);

        loadMovies();

        btnAddReview.setOnClickListener(v -> {
            String name = etMovieName.getText().toString();
            String yearStr = etMovieYear.getText().toString();
            String ratingStr = etMovieRating.getText().toString();

            if (!name.isEmpty() && !yearStr.isEmpty() && !ratingStr.isEmpty()) {
                int year = Integer.parseInt(yearStr);
                int rating = Integer.parseInt(ratingStr);

                if (rating < 1 || rating > 5) {
                    Toast.makeText(this, "Rating must be between 1 and 5", Toast.LENGTH_SHORT).show();
                    return;
                }

                databaseHelper.addReview(name, year, rating);
                loadMovies();
                etMovieName.setText("");
                etMovieYear.setText("");
                etMovieRating.setText("");
                Toast.makeText(this, "Review Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        listMovies.setOnItemClickListener((adapterView, view, position, id) -> {
            String selectedMovie = movieList.get(position);
            Cursor cursor = databaseHelper.getMovieDetails(selectedMovie);

            if (cursor.moveToFirst()) {
                tvMovieName.setText(cursor.getString(1));
                tvMovieYear.setText(String.valueOf(cursor.getInt(2)));
                tvMovieRating.setText(String.valueOf(cursor.getInt(3)));
                tableMovieDetails.setVisibility(View.VISIBLE);
            }
            cursor.close();
        });
    }

    private void loadMovies() {
        movieList.clear();
        Cursor cursor = databaseHelper.getAllMovies();
        if (cursor.moveToFirst()) {
            do {
                movieList.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
}