package com.example.groceryques;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText etItemName, etItemCost;
    Button btnAdd, btnCalculate;
    Spinner spinnerItems;
    TextView tvTotalCost;
    ArrayList<String> itemList;
    ArrayAdapter<String> adapter;
    double totalCost = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        etItemName = findViewById(R.id.et_item_name);
        etItemCost = findViewById(R.id.et_item_cost);
        btnAdd = findViewById(R.id.btn_add);
        btnCalculate = findViewById(R.id.btn_calculate);
        spinnerItems = findViewById(R.id.spinner_items);
        tvTotalCost = findViewById(R.id.tv_total_cost);

        itemList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, itemList);
        spinnerItems.setAdapter(adapter);

        loadItems();

        btnAdd.setOnClickListener(v -> {
            String itemName = etItemName.getText().toString();
            String itemCostStr = etItemCost.getText().toString();

            if (!itemName.isEmpty() && !itemCostStr.isEmpty()) {
                double itemCost = Double.parseDouble(itemCostStr);
                databaseHelper.addItem(itemName, itemCost);
                loadItems();
                etItemName.setText("");
                etItemCost.setText("");
                Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter both item name and cost", Toast.LENGTH_SHORT).show();
            }
        });

        btnCalculate.setOnClickListener(v -> {
            String selectedItem = spinnerItems.getSelectedItem().toString();
            double itemCost = databaseHelper.getItemCost(selectedItem);
            totalCost += itemCost;
            tvTotalCost.setText("Total Cost: " + totalCost);
        });
    }

    private void loadItems() {
        itemList.clear();
        Cursor cursor = databaseHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                itemList.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
}